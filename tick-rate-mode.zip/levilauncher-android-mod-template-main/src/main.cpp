#include "mod/MyMod.h"

#include <pl/Mod.hpp>

PL_REGISTER_MOD(tick_rate::TickRateMod, tick_rate::TickRateMod::instance());
