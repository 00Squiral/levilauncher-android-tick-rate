#include "mod/MyMod.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <dlfcn.h>
#include <filesystem>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

#include <pl/ModMenu.hpp>
#include <pl/memory/Signature.hpp>

namespace tick_rate {

namespace {

constexpr const char *kMenuId = "tick_rate_module";
constexpr const char *kModuleName = "libminecraftpe.so";
constexpr float kVanillaTps = 20.0f;
constexpr size_t kScanBytes = 0x40; // how far into a Timer we look for the tps float

std::atomic<float> gTps{kVanillaTps};
std::atomic<bool> gActive{false};
std::atomic<int> gTimerIndex{-1};

using AdvanceTimeFn = void (*)(void *, float);
AdvanceTimeFn gOrigAdvanceTime = nullptr;

struct TimerInfo {
    int index = -1;       // order in which we first saw it (among 20-TPS timers)
    int fieldOffset = -1; // byte offset of the tps float, -1 = not a tick timer
};
std::mutex gTimersMutex;
std::unordered_map<void *, TimerInfo> gTimers;
int gNextIndex = 0;

// Find the float == 20.0f in the first bytes of the object. Offset is cached per Timer*.
TimerInfo &classify(void *timer, ll::mod::NativeMod &self) {
    auto [it, inserted] = gTimers.try_emplace(timer);
    if (!inserted)
        return it->second;

    auto *base = reinterpret_cast<const unsigned char *>(timer);
    for (size_t off = 0; off + sizeof(float) <= kScanBytes; off += sizeof(float)) {
        float v;
        std::memcpy(&v, base + off, sizeof(v));
        if (v == kVanillaTps) {
            it->second.fieldOffset = static_cast<int>(off);
            it->second.index = gNextIndex++;
            self.getLogger().info("Timer {} detected: tps field at +0x{:x} (timer index {})",
                                  timer, off, it->second.index);
            break;
        }
    }
    if (it->second.fieldOffset < 0)
        self.getLogger().debug("Timer {} ignored (no 20.0 float in first 0x{:x} bytes)", timer,
                               kScanBytes);
    return it->second;
}

void detourAdvanceTime(void *timer, float preferredFrameTime) {
    if (timer) {
        std::lock_guard lock(gTimersMutex);
        auto &info = classify(timer, TickRateMod::instance().getSelf());
        int wanted = gTimerIndex.load(std::memory_order_relaxed);
        if (info.fieldOffset >= 0 && (wanted < 0 || wanted == info.index)) {
            // Inactive -> keep writing vanilla 20 so toggling the module off restores speed.
            float tps = gActive.load(std::memory_order_relaxed)
                            ? gTps.load(std::memory_order_relaxed)
                            : kVanillaTps;
            std::memcpy(reinterpret_cast<unsigned char *>(timer) + info.fieldOffset, &tps,
                        sizeof(tps));
        }
    }
    gOrigAdvanceTime(timer, preferredFrameTime);
}

float clampTps(float v) {
    if (!std::isfinite(v))
        return kVanillaTps;
    return std::clamp(v, 0.1f, 1000.0f);
}

} // namespace

TickRateMod &TickRateMod::instance() {
    static TickRateMod instance;
    return instance;
}

TickRateMod::TickRateMod() : mSelf(*ll::mod::NativeMod::current()) {}

void TickRateMod::setTps(float tps) { gTps.store(clampTps(tps), std::memory_order_relaxed); }

float TickRateMod::getTps() const { return gTps.load(std::memory_order_relaxed); }

bool TickRateMod::load() {
    auto &self = getSelf();
    self.getLogger().debug("Loading...");

    std::error_code ec;
    std::filesystem::create_directories(self.getDataDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create data directory {}: {}",
                               self.getDataDir().string(), ec.message());
        return false;
    }
    std::filesystem::create_directories(self.getConfigDir(), ec);
    if (ec) {
        self.getLogger().error("Failed to create config directory {}: {}",
                               self.getConfigDir().string(), ec.message());
        return false;
    }

    mConfigFile.emplace();
    if (!mConfigFile->load()) {
        self.getLogger().warn("Failed to load typed config");
        return false;
    }
    mConfig = mConfigFile->value();
    setTps(mConfig.tps);
    gTimerIndex.store(mConfig.timerIndex);

    self.getLogger().info("Loaded {} from {}", self.getName(), self.getModDir().string());
    return true;
}

bool TickRateMod::installHook() {
    auto &log = getSelf().getLogger();

    void *target = nullptr;

    // 1) exported symbol
    if (!mConfig.advanceTimeSymbol.empty()) {
        if (void *h = dlopen(kModuleName, RTLD_NOW | RTLD_NOLOAD)) {
            target = dlsym(h, mConfig.advanceTimeSymbol.c_str());
            dlclose(h);
        }
        if (target)
            log.info("Timer::advanceTime found via symbol at {}", target);
    }

    // 2) byte signature from config
    if (!target && !mConfig.advanceTimeSignature.empty()) {
        uintptr_t addr = pl::memory::resolveSignature(mConfig.advanceTimeSignature, kModuleName);
        if (addr) {
            target = reinterpret_cast<void *>(addr);
            log.info("Timer::advanceTime found via signature at {}", target);
        }
    }

    if (!target) {
        log.error("Timer::advanceTime not found. Set advanceTimeSignature in config.json "
                  "for this Minecraft version.");
        return false;
    }

    mHook = pl::memory::HookHandle(target, reinterpret_cast<void *>(&detourAdvanceTime),
                                   reinterpret_cast<void **>(&gOrigAdvanceTime));
    if (!mHook.installed()) {
        log.error("Failed to hook Timer::advanceTime");
        return false;
    }
    return true;
}

void TickRateMod::registerMenu() {
    auto &log = getSelf().getLogger();
    bool ok =
        pl::modmenu::ModuleBuilder(kMenuId, "Tick Rate")
            .description("Change the game tick rate (vanilla = 20 TPS).")
            .modId(getSelf().getId())
            .defaultEnabled(mConfig.enabled)
            .config("tps", "Ticks per second", pl::modmenu::ConfigType::SliderFloat,
                    std::to_string(mConfig.tps), "1", "200")
            .onToggle([](std::string_view, bool enabled) {
                gActive.store(enabled);
            })
            .onConfigChanged([this](std::string_view, std::string_view key, std::string_view value) {
                if (key != "tps")
                    return;
                char *end = nullptr;
                std::string s(value);
                float v = std::strtof(s.c_str(), &end);
                if (end != s.c_str()) {
                    setTps(v);
                    gActive.store(true);
                }
            })
            .registerModule();
    if (!ok)
        log.warn("Could not register Mod Menu module (slider unavailable)");
}

bool TickRateMod::enable() {
    auto &self = getSelf();
    self.getLogger().debug("Enabling...");
    if (!mConfig.enabled) {
        self.getLogger().info("Tick Rate Mode is disabled by config");
        return true;
    }

    gActive.store(true);
    if (!installHook())
        return true; // keep the game running even if the hook failed
    registerMenu();
    self.getLogger().info("Tick Rate Mode active at {} TPS", getTps());
    return true;
}

bool TickRateMod::disable() {
    getSelf().getLogger().debug("Disabling...");
    gActive.store(false);
    pl::modmenu::unregisterModule(kMenuId);
    mHook.reset();
    return true;
}

bool TickRateMod::unload() {
    getSelf().getLogger().debug("Unloading...");
    mConfigFile.reset();
    return true;
}

} // namespace tick_rate
