#pragma once

#include <optional>

#include "mod/Config.h"

#include <pl/Mod.hpp>
#include <pl/memory/Hook.hpp>

namespace tick_rate {

class TickRateMod {
  public:
    static TickRateMod &instance();

    TickRateMod();

    [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

    // Called by the Timer::advanceTime detour (game thread).
    void onAdvanceTime(void *timer);

    void setTps(float tps);
    [[nodiscard]] float getTps() const;

  private:
    bool installHook();
    void registerMenu();

    ll::mod::NativeMod &mSelf;
    ModConfig mConfig;
    std::optional<pl::config::ConfigFile<ModConfig>> mConfigFile;
    pl::memory::HookHandle mHook;
};

} // namespace tick_rate
