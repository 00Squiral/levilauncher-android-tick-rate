#pragma once

#include <string>
#include <string_view>

#include <pl/Config.hpp>

namespace tick_rate {

struct ModConfig {
    int version = 1;
    bool enabled = true;
    float tps = 20.0f;
    // Symbol tried first (works if libminecraftpe.so still exports symbols).
    std::string advanceTimeSymbol = "_ZN5Timer11advanceTimeEf";
    // Fallback: IDA-style byte pattern for Timer::advanceTime(float), e.g. "FD 7B ?? A9 ...".
    // Fill this in config.json if the symbol lookup fails - no rebuild needed.
    std::string advanceTimeSignature = {};
    // -1 = affect every detected 20-TPS timer. 0/1/... = only that timer (see log).
    int timerIndex = -1;
};

nlohmann::json makeDefaultConfigJson();
nlohmann::json makeConfigSchemaJson();

} // namespace tick_rate

template <> struct pl::config::Schema<tick_rate::ModConfig> {
    static constexpr std::string_view title = "Tick Rate Config";
    static constexpr std::string_view description = {};

    static constexpr FieldSchema field(std::string_view name) {
        if (name == "version")
            return {.title = "Version", .readOnly = true};
        if (name == "enabled")
            return {.title = "Enabled", .description = "Turns the tick rate override on or off."};
        if (name == "tps")
            return {.title = "Ticks per second", .description = "Game tick rate. Vanilla is 20.",
                    .minimum = 0.1, .maximum = 1000.0};
        if (name == "advanceTimeSymbol")
            return {.title = "Timer::advanceTime symbol"};
        if (name == "advanceTimeSignature")
            return {.title = "Timer::advanceTime signature",
                    .description = "Byte pattern used if the symbol lookup fails."};
        if (name == "timerIndex")
            return {.title = "Timer index",
                    .description = "-1 affects all detected timers; use 0 or 1 to pick one."};
        return {};
    }
};
